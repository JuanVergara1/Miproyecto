package com.smartstaysolutions.mihotel.service;


import com.smartstaysolutions.mihotel.model.Reserva;
import com.smartstaysolutions.mihotel.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;


    public Reserva saveReserva(Reserva reserva) {
        return reservaRepository.save(reserva);
    }

}
