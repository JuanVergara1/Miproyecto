package com.smartstaysolutions.mihotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MihotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(MihotelApplication.class, args);
	}

}
