package com.smartstaysolutions.mihotel.service;

import com.smartstaysolutions.mihotel.model.Contacto;
import com.smartstaysolutions.mihotel.repository.ContactoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactoService {


    @Autowired
    private ContactoRepository contactoRepository;

    public Contacto saveContacto(Contacto contacto) {
        return contactoRepository.save(contacto);
    }
}
