package com.smartstaysolutions.mihotel.controller;


import com.smartstaysolutions.mihotel.service.ContactoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contacto")


@CrossOrigin(origins = "*")

public class ContactoController {

    @Autowired
    private ContactoService contactoService;










}
