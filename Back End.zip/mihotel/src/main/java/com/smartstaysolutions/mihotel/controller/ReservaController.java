package com.smartstaysolutions.mihotel.controller;

import com.smartstaysolutions.mihotel.model.Reserva;
import com.smartstaysolutions.mihotel.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("")
@CrossOrigin("*")
public class ReservaController {

    @Autowired
    private ReservaRepository reservaRepository;
    public ReservaController(ReservaRepository reservaRepository) {
        this.reservaRepository = reservaRepository;
    }

    @PostMapping("/PagReserva")
    public String crearReserva(@RequestParam String nombre,
                               @RequestParam String email,
                               @RequestParam String telefono,
                               @RequestParam String fecha_entrada,
                               @RequestParam String fecha_salida,
                               @RequestParam String tipo_habitacion,
                               @RequestParam(required = false) String comentarios) {
        Reserva reserva = new Reserva();
        reserva.setNombre(nombre);
        reserva.setEmail(email);
        reserva.setTelefono(telefono);
        reserva.setFecha_entrada(fecha_entrada);
        reserva.setFecha_salida(fecha_salida);
        reserva.setTipo_habitacion(tipo_habitacion);
        reserva.setComentarios(comentarios);

        reservaRepository.save(reserva);
        return "LA RESERVA FUE EXITOSA. " +
                "POR FAVOR, si desea volver a reservar limpie los campos.";
    }




}

