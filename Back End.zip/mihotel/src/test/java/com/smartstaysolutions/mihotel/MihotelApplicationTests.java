package com.smartstaysolutions.mihotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MihotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
